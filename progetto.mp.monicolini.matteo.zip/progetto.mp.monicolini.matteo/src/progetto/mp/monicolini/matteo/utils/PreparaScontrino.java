package progetto.mp.monicolini.matteo.utils;

import progetto.mp.monicolini.matteo.puntocaldo.ScontrinoIngredienti;

public interface PreparaScontrino {
	
	public void prepara(ScontrinoIngredienti scontrino);

}
