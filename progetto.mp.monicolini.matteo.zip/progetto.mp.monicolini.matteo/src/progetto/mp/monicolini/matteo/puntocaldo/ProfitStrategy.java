package progetto.mp.monicolini.matteo.puntocaldo;

public interface ProfitStrategy {
	
	double aggiungiProfitto(double costoIntrinseco);
}
