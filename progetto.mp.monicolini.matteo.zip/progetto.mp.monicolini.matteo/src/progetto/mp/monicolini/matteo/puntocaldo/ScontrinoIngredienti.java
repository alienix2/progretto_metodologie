package progetto.mp.monicolini.matteo.puntocaldo;

public interface ScontrinoIngredienti {
	
	public void aggiungiInCoda(String aggiunta);
	
	public void aggiungiInTesta(String aggiunta);
	
}
